#include "gestionUtils.h"
//INTERFACE ADMIN
//MODIFIER
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Admin")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbadmmodif_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbempmodif_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvmodif_wadm), u.log.cin);
    }
  }
}
fclose(f1);

//SUPPRIMER (avant return sup_wadm)
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Admin")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbadmsup_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbempsup_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvsup_wadm), u.log.cin);
    }
  }
}
fclose(f1);

//ABSENCES
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbempabs_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvabs_wadm), u.log.cin);
    }
  }
}
fclose(f1);

//ABSENCES TAUX
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbemptaux_wadm), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvtaux_wadm), u.log.cin);
    }
  }
}
fclose(f1);

//INTERFACE EMPlOYE
//MODIFIER
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbempmodif_wemp), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvmodif_wemp), u.log.cin);
    }
  }
}
fclose(f1);

//SUPPRIMER (avant return sup_wemp)
FILE *f1;
UTILISATEUR u;
f1 = fopen("users.txt", "r");
if (f1 != NULL)
{
  while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
  {
    if ((strcmp(u.role, "Employe")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbempsup_wemp), u.log.cin);
    }
    else if ((strcmp(u.role, "Ouvrier")) == 0)
    {
      gtk_combo_box_append_text(GTK_COMBO_BOX(cbouvsup_wemp), u.log.cin);
    }
  }
}
fclose(f1);