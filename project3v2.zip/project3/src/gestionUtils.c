#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "gestionUtils.h"

enum
{

    UCIN,
    UPASSWORD,
    UNOM,
    UPRENOM,
    UDATE,
    UNUMTEL,
    USEXE,
    UROLE,
    COLUMNS
};
enum
{
    OCIN,
    ONOM,
    OPRENOM,
    OJTRAV,
    OJABS,
    OTAUX,
    COLUMNS_TAUX
};

//Definition des fonctions
/*---------------------------/CONTROLE-SAISIE/---------------------------*/
//Verification du CIN : 0 -> cin erroné | 1 -> cin ok
int verifCin(char cin[])
{
    int t = 1;

    if ((strlen(cin) != 8) || (!isdigit(cin[0]) || !isdigit(cin[1]) || !isdigit(cin[2]) || !isdigit(cin[3]) || !isdigit(cin[4]) || !isdigit(cin[5]) || !isdigit(cin[6]) || !isdigit(cin[7])))
        t = 0;

    return t;
}
//Verification que la chaine est un numero : 1 -> faux / 0 -> vrai
int verifNum(char num[])
{
    int t = 0;
    int i = 0;
    for (i = 0; i < strlen(num); i++)
    {
        if (isdigit(num[i]))
        {
            t = 1;
            break;
        }
    }
    return t;
}
//Verification du role : 1 -> existe / 0 -> non
int verifRole(char role[], char fich[])
{
    UTILISATEUR u;
    int test = 0;
    FILE *f1;
    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(u.role, role) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
        return test;
    }
}
//Verification de l'existance de l'utilisateur : 1 -> existe / 0 -> non
int verifUtils(char cin[], char fich[])
{
    UTILISATEUR u;
    int test = 0;
    FILE *f1;
    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(cin, u.log.cin) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
        return test;
    }
}
void suppEspaces(char chaine[])
{
    int c = 0;
    for (int i = 0; chaine[i]; i++)
    {
        if (chaine[i] != ' ')
        {
            chaine[c++] = chaine[i];
        }
    }
    chaine[c] = '\0';
}
/*---------------------------/C-R-U-D/---------------------------*/
/*---------------------------/TACHE1/---------------------------*/
//Ajout d'un utilisateur (Admin,Employe,Ouvrier)
void ajoutUtils(UTILISATEUR u, char fich[])
{
    FILE *f;
    sprintf(u.dateNaiss, "%d/%d/%d", u.date.jour, u.date.mois, u.date.annee);
    f = fopen(fich, "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
        fclose(f);
    }
}

//Modification des informations
void modifUtils(UTILISATEUR m, char cin[], char fich[])
{
    UTILISATEUR u;
    FILE *f1 = NULL, *f = NULL;
    sprintf(m.dateNaiss, "%d/%d/%d", m.date.jour, m.date.mois, m.date.annee);
    sprintf(u.dateNaiss, "%d/%d/%d", u.date.jour, u.date.mois, u.date.annee);
    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if ((f != NULL) && (f1 != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(cin, u.log.cin) != 0)
            {
                fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            else
            {
                fprintf(f1, "%s %s %s %s %s %s %s %s \n", m.log.cin, m.log.pw, m.nom, m.prenom, m.dateNaiss, m.numTel, m.sexe, m.role);
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Suppression d'un utilisateur
void suppUtils(char cin[], char fich[])
{
    UTILISATEUR u;
    FILE *f1 = NULL, *f = NULL;

    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (f1 != NULL)
            {
                if (strcmp(u.log.cin, cin) != 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Recherche des informations d'un utilisateur
UTILISATEUR rechUtils(char cin[], char fich[])
{
    FILE *f = NULL;
    UTILISATEUR u;
    //sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
    f = fopen(fich, "r");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(cin, u.log.cin) == 0)
            {
                return u;
            }
        }
    }
    fclose(f);
}

//Affichage
void affUtils(GtkWidget *treeview, char fich[])
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    UTILISATEUR u;
    gtk_list_store_clear(treeview);
    FILE *f = NULL;
    store = gtk_tree_view_get_model(treeview);
    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" CIN", renderer, "text", UCIN, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" MOT DE PASSE", renderer, "text", UPASSWORD, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" NOM", renderer, "text", UNOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" PRENOM", renderer, "text", UPRENOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" DATE DE NAISSANCE", renderer, "text", UDATE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" NUMERO TEL", renderer, "text", UNUMTEL, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" SEXE", renderer, "text", USEXE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" ROLE", renderer, "text", UROLE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeview), column);
    }
    store = gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
    f = fopen(fich, "r");
    if (f == NULL)
    {
        return;
    }
    else
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, UCIN, u.log.cin, UPASSWORD, u.log.pw, UNOM, u.nom, UPRENOM, u.prenom, UDATE, u.dateNaiss, UNUMTEL, u.numTel, USEXE, u.sexe, UROLE, u.role, -1);
        }
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeview), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
    fclose(f);
}

/*---------------------------/GESTION-DES-ABSENCES/---------------------------*/
/*---------------------------/TACHE2/---------------------------*/
OUVRIER dateAuj(OUVRIER o)
{
    time_t t;
    struct tm *tmp;
    char date[100];
    time(&t);
    tmp = localtime(&t);
    strftime(date, sizeof(date), "%d/%m/%Y", tmp);
    sscanf(date, "%d/%d/%d", &o.dateAbs.jour, &o.dateAbs.mois, &o.dateAbs.annee);
    return o;
}
void marquerAbs(OUVRIER o, char fich[])
{
    FILE *f1;
    f1 = fopen(fich, "a+");
    if (f1 != NULL)
    {
        fprintf(f1, "%s %s %s %s\n", o.logAbs.cin, o.date, o.valAbs, o.roleAbs);
        fclose(f1);
    }
}
void tauxAbs(char fich1[], char fich2[])
{
    UTILISATEUR u;
    OUVRIER o;
    float jabs = 0;
    float jtrav = 0;
    int i = 0, j = 0;
    FILE *f1, *f2, *f3;

    f1 = fopen(fich1, "r");
    f3 = fopen("taux.txt", "w");
    if ((f1 != NULL) && (f3 != NULL))
    {
        while ((fscanf(f1, "%s %s %s %s %s %s %s %s\n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF))
        {
            f2 = fopen(fich2, "r");
            if (f2 != NULL)
            {
                while (fscanf(f2, "%s %s %s %s\n", o.logAbs.cin, o.date, o.valAbs, o.roleAbs) != EOF)
                {
                    if (strcmp(u.log.cin, o.logAbs.cin) == 0)
                    {
                        if (strcmp(o.valAbs, "Absent") == 0)
                        {
                            jabs++;
                        }
                        jtrav++;
                    }
                }
            }
            fprintf(f3, "%s %s %s %.f %.f %.2f%%\n", u.log.cin, u.nom, u.prenom, jtrav, jabs, (jabs / jtrav) * 100);
            jtrav = 0;
            jabs = 0;
        }
    }
    fclose(f3);
    fclose(f1);
    fclose(f2);
}
void affAbs(GtkWidget *treeviewaffabs, char fich[])
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    OUVRIER o;
    UTILISATEUR u;
    gtk_list_store_clear(treeviewaffabs);
    FILE *f = NULL;
    store = gtk_tree_view_get_model(treeviewaffabs);
    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" CIN", renderer, "text", OCIN, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" NOM", renderer, "text", ONOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" PRENOM", renderer, "text", OPRENOM, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" JOURS DE TRAVAILLE", renderer, "text", OJTRAV, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" JOURS D'ABSENCE", renderer, "text", OJABS, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" TAUX D'ABSENTEISME", renderer, "text", OTAUX, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewaffabs), column);
    }
    store = gtk_list_store_new(COLUMNS_TAUX, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    f = fopen(fich, "r");
    if (f == NULL)
    {
        return;
    }
    else
    {

        while (fscanf(f, "%s %s %s %s %s %s\n", u.log.cin, u.nom, u.prenom, o.jtrav, o.jabs, o.taux) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, OCIN, u.log.cin, ONOM, u.nom, OPRENOM, u.prenom, OJTRAV, o.jtrav, OJABS, o.jabs, OTAUX, o.taux, -1);
        }
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewaffabs), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
    fclose(f);
}