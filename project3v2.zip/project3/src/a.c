#include <stdio.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>

typedef struct
{
    int jour, mois, annee;

} DATE;

typedef struct
{
    char cin[50];
    char pw[50];
} LOGIN;

typedef struct
{
    LOGIN log;
    char nom[50];
    char prenom[50];
    char dateNaiss[50];
    char numTel[50];
    char sexe[50];
    char role[50];
    DATE date;
} UTILISATEUR;

typedef struct
{
    DATE dateAbs;
    LOGIN logAbs;
} OUVRIER;

OUVRIER dateAuj(OUVRIER o)
{
    time_t t;
    struct tm *tmp;
    char date[100];
    time(&t);
    tmp = localtime(&t);
    strftime(date, sizeof(date), "%d/%m/%Y", tmp);
    sscanf(date, "%d/%d/%d", &o.dateAbs.jour, &o.dateAbs.mois, &o.dateAbs.annee);
    return o;
}
int main()
{
    OUVRIER u;
    u = dateAuj(u);
    printf("Jour  : %d\n", u.dateAbs.jour);
    printf("Mois  : %d\n", u.dateAbs.mois);
    printf("Annee : %d\n", u.dateAbs.annee);
    return (0);
}