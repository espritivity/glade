#include <gtk/gtk.h>


void
on_buttonModifier_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonClientFidele_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAfficher_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_AjouterValider_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_AjouterRetour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_ModifierRetour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_TreeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_AfficherRechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_SuccValider_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ButtonOnView_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_AuthConnexion_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_AuthQuitter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonokmodifier_clicked            (GtkButton       *button,
                                        gpointer         user_data);



void
on_buttonAfficher_rechercher_clicked   (GtkButton       *button,
                                        gpointer         user_data);


void
on_afficherretour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonDeconneter_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_affichercf_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherchecf_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichercf_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_ajoutercf_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourcf_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_retourclientfidele_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_show_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserr_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
