#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <ctype.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"

int Homme,Femme,ModifierHomme,ModifierFemme;
void
on_buttonModifier_Supprimer_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *modifier;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    modifier = lookup_widget(button, "modifier");
    modifier = create_modifier();
    gtk_widget_show(modifier);

}


void
on_buttonClientFidele_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *ajoutcf;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    ajoutcf = lookup_widget(button, "ajoutcf");
    ajoutcf = create_ajoutcf();
    gtk_window_set_position(GTK_WINDOW(ajoutcf), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajoutcf);


}


void
on_buttonAjouter_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *ajouter;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    ajouter = lookup_widget(button, "ajouter");
    ajouter = create_ajouter();
    gtk_window_set_position(GTK_WINDOW(ajouter), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajouter);


}





void
on_homme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        Homme = 1;
    }

}


void
on_Femme_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        Femme = 2;
    }

}


void
on_AjouterValider_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    char fich[20];
    strcpy(fich, "client.txt");
   CLIENT u;
    GtkWidget *cin, *nom, *prenom, *nationalite ,*sexe;
    GtkWidget *output_ajout;
    GtkWidget *ajouter, *Success, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj");

    cin = lookup_widget(button, "AjouterCin");
    nom = lookup_widget(button, "AjouterNom");
    prenom = lookup_widget(button, "AjouterPrenom");
    nationalite = lookup_widget(button, "AjouterNationalite");
    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifClient(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "Le client existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }

    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.nationalite, gtk_combo_box_get_active_text(GTK_COMBO_BOX(nationalite)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

  
        strcpy(u.sexe, "Homme");
        if (Homme == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (Femme == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutClient(u, fich);
        ajouter = lookup_widget(button, "ajouter");
        Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

}
}
/////////////////////////

void
on_AjouterRetour_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *buttonAjouter;

    buttonAjouter = lookup_widget(button, "ajouter");
    gtk_widget_destroy(buttonAjouter);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);


}


void
on_ModifierRetour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *modifier;

    modifier = lookup_widget(button, "modifier");
    gtk_widget_destroy(modifier);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_supprimer_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ModifierCin,*msg_succ,*Success;
char cin[50];
char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
ModifierCin=lookup_widget (button,"ModifierCin");
    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
supprimer(cin);
 
 Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client supprimer avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);


}
/////change

void
on_Modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
CLIENT c;
char msg[50], *markup,*msg_succ,*Success;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

  GtkWidget *ModifierNom;
  GtkWidget *ModifierPrenom;
  GtkWidget *ModifierCin;
  GtkWidget *ModifierNationalite;
  GtkWidget *ModifierHomme;
  GtkWidget *ModifierFemme;

  ModifierHomme = lookup_widget(button, "ModifierHomme");
  ModifierFemme = lookup_widget(button, "ModifierFemme");
  ModifierNom = lookup_widget(button, "ModifierNom");
  ModifierPrenom = lookup_widget(button, "ModifierPrenom");
  ModifierCin = lookup_widget(button, "ModifierCin");
  ModifierNationalite = lookup_widget(button, "ModifierNationalite");
  strcpy(c.nom, gtk_entry_get_text(GTK_ENTRY(ModifierNom)));
  strcpy(c.prenom, gtk_entry_get_text(GTK_ENTRY(ModifierPrenom)));
  strcpy(c.cin, gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
  strcpy(c.nationalite, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ModifierNationalite)));

  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ModifierFemme)))
  {
    strcpy(c.sexe, "Femme");
  }
  else if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ModifierHomme)))
  {
    strcpy(c.sexe, "Homme");
  }
  modifier(c,gtk_entry_get_text(GTK_ENTRY(ModifierCin)));
Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client modifier avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

    }



void
on_TreeviewAfficher_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
CLIENT c;
  GtkTreeIter iter;
  gchar *nom;
  gchar *prenom;
  gchar *cin;
  gchar *nationalite;
  gchar *sexe;
  GtkWidget *afficher;
  GtkWidget *TreeviewAfficher;
  GtkWidget *modifier;
  GtkWidget *NOM;
  GtkWidget *PRENOM;
  GtkWidget *CIN;
  GtkWidget *NATIONALITE;
  GtkWidget *HOMME;
  GtkWidget *FEMME;

  afficher = lookup_widget(TreeviewAfficher, "afficher");
  GtkTreeModel *model = gtk_tree_view_get_model(TreeviewAfficher);
  if (gtk_tree_model_get_iter(model, &iter, path))
 {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &nom, 1, &prenom, 2, &cin, 3, &nationalite , 4, &sexe, -1);
        strcpy(c.cin, cin);
        strcpy(c.nationalite, nationalite);
        strcpy(c.nom, nom);
        strcpy(c.prenom, prenom);
        strcpy(c.sexe, sexe);

    modifier = create_modifier();
    gtk_widget_hide(afficher);
    gtk_widget_show(modifier);

    NOM = lookup_widget(modifier, "ModifierNom");
    PRENOM = lookup_widget(modifier, "ModifierPrenom");
    CIN = lookup_widget(modifier, "ModifierCin");
    NATIONALITE = lookup_widget(modifier, "ModifierNationalite");
    HOMME = lookup_widget(modifier, "ModifierHomme");
    FEMME = lookup_widget(modifier, "ModifierFemme");

    gtk_entry_set_text(GTK_ENTRY(NOM), nom);
    gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
    gtk_entry_set_text(GTK_ENTRY(CIN), cin);
    gtk_entry_set_text(GTK_COMBO_BOX(NATIONALITE), nationalite);
    if ((strcmp(c.sexe, "Homme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
    }
    else if ((strcmp(c.sexe, "Femme") == 0))
    {
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
      gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
    }
  }
}



void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
 GtkWidget *afficher;
  GtkWidget *TreeviewAfficher;

  afficher = lookup_widget(button, "afficher");
  TreeviewAfficher = lookup_widget(afficher, "TreeviewAfficher");
  gtk_widget_show(afficher);
strcpy(fich, "client.txt");
  affClient(TreeviewAfficher, fich);

}


void
on_AfficherRechercher_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
  CLIENT c;
  GtkWidget *afficher;
  GtkWidget *AfficherCin;
  GtkWidget *TreeviewAfficher;
  FILE *f;
  FILE *f2;
  char cin[30];
//////////////////
  afficher = lookup_widget(button, "afficher");
  AfficherCin = lookup_widget(button, "AfficherCin");
  strcpy(cin, gtk_entry_get_text(GTK_ENTRY(AfficherCin)));
  f = fopen("client.txt", "r");

  if (f != NULL)
  {
    while (fscanf(f, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe) != EOF)
    {
      f2 = fopen("temp.txt", "a+");
      if (f2 != NULL)
      {
        if ((strcmp(c.cin, cin) == 0))
        {
          fprintf(f2, "%s %s %s %s %s  \n", c.nom, c.prenom,c.cin,c.nationalite,c.sexe);
        }
        TreeviewAfficher = lookup_widget(afficher, "TreeviewAfficher");
        rechClient(TreeviewAfficher);
        fclose(f2);
      }
    }

    fclose(f);
  }
  remove("temp.txt");

}


void
on_SuccValider_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *Success;

    Success = lookup_widget(button, "Success");
    gtk_widget_destroy(Success);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);
}


void
on_ButtonOnView_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AuthConnexion_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_AuthQuitter_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}






void
on_buttonAfficher_rechercher_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestionclient;
    GtkWidget *afficher;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    afficher = lookup_widget(button, "afficher");
    afficher = create_afficher();
    gtk_window_set_position(GTK_WINDOW(afficher), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(afficher);

}




void
on_afficherretour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *gestionclient;
    GtkWidget *afficher;

    afficher = lookup_widget(button, "afficher");
    gtk_widget_destroy(afficher);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_buttonDeconneter_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *Authentification;

    gestionclient = lookup_widget(button, "gestionclient");
    gtk_widget_destroy(gestionclient);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);

}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
CLIENT c;
  GtkTreeIter iter;
  gchar *prix;
  gchar *cin;
  GtkWidget *ClientFidele;
  GtkWidget *treeview1;
  GtkWidget *PRIX;
  GtkWidget *CIN;


  ClientFidele = lookup_widget(treeview1, "ClientFidele");
  GtkTreeModel *model = gtk_tree_view_get_model(treeview1);
  if (gtk_tree_model_get_iter(model, &iter, path))
 {
    gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &prix, -1);
        strcpy(c.cin, cin);
        strcpy(c.prix, prix);
  }

}


void
on_affichercf_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
 GtkWidget *ClientFidele;
  GtkWidget *treeview1;

  ClientFidele = lookup_widget(button, "ClientFidele");
  treeview1 = lookup_widget(ClientFidele, "treeview1");
  gtk_widget_show(ClientFidele);
strcpy(fich, "clientfid.txt");
  affClientfid(treeview1, fich);

}


void
on_recherchecf_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{

}
/////////////////

void
on_buttonaffichercf_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
    GtkWidget *ClientFidele;
    GtkWidget *ajoutcf;

    ajoutcf = lookup_widget(button, "ajoutcf");
    gtk_widget_destroy(ajoutcf);

    ClientFidele = lookup_widget(button, "ClientFidele");
    ClientFidele = create_ClientFidele();
    gtk_window_set_position(GTK_WINDOW(ClientFidele), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ClientFidele);

}


void
on_ajoutercf_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
    char fich[20],fich1[20];
    strcpy(fich, "clientfid.txt");
    strcpy(fich1, "client.txt");
   CLIENT u;
    GtkWidget *cin, *prix;
    GtkWidget *output_ajouter;
    GtkWidget *ajoutcf, *Success, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajouter = lookup_widget(button, "outputajouter");

    cin = lookup_widget(button, "cincf");
    prix = lookup_widget(button, "prixcf");
    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajouter), markup);
    }
    else if (!verifClient(gtk_entry_get_text(GTK_ENTRY(cin)), fich1))
    {
        sprintf(msg, "Le client n' existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajouter), markup);
    }

    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.prix, gtk_entry_get_text(GTK_ENTRY(prix)));

///////////////////////////////////////
        ajouterclientfid(u, fich);
        ajoutcf = lookup_widget(button, "ajoutcf");
        Success = lookup_widget(button, "Success");
        Success = create_Success();
        gtk_window_set_title(GTK_WINDOW(Success), "Success");
        gtk_window_set_position(GTK_WINDOW(Success), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(Success);
        msg_succ = lookup_widget(Success, "rblabelsucc");
        sprintf(msg, "Client et achat ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);

}

}


void
on_retourcf_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *ClientFidele;

    ClientFidele = lookup_widget(button, "ClientFidele");
    gtk_widget_destroy(ClientFidele);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_retourclientfidele_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
 GtkWidget *gestionclient;
    GtkWidget *ClientFidele;

    ClientFidele = lookup_widget(button, "ClientFidele");
    gtk_widget_destroy(ClientFidele);

    gestionclient = lookup_widget(button, "gestionclient");
    gestionclient = create_gestionclient();
    gtk_window_set_position(GTK_WINDOW(gestionclient), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionclient);

}


void
on_show_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *nom, *prenom, *cin, *sexe, *nationalite, *homme, *femme;
    CLIENT u;
    nom = lookup_widget(button, "ModifierNom");
    prenom = lookup_widget(button, "ModifierPrenom");
    cin = lookup_widget(button, "ModifierCin");
    nationalite = lookup_widget(button, "ModifierNationalite");
    homme = lookup_widget(button, "ModifierHomme");
    femme = lookup_widget(button, "ModifierFemme");
       
    u = recheClient(gtk_entry_get_text(GTK_ENTRY(cin)));
        
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(cin), u.cin);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
///////////////
    if((strcmp(u.nationalite,"Tunisienne")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite),0);
    }
    if((strcmp(u.nationalite,"Etrangere")==0))
    {
        gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite),1);
    }
///////////////
       // gtk_combo_box_set_active(GTK_COMBO_BOX(nationalite), u.nationalite);


        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(Homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(Femme), 1);
      
        }

}




void
on_actualiserr_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
char fich[20];
    GtkWidget *treeview1,*afficher;
    afficher=lookup_widget(button,"afficher");
    gtk_widget_destroy(afficher);
    afficher=create_afficher();
    gtk_widget_show(afficher);
    treeview1=lookup_widget(afficher,"treeview1");
strcpy(fich, "client.txt");
  affClient(treeview1, fich);

}

