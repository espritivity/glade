#include <gtk/gtk.h>

void on_buttonaj_wadm_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonmod_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonsup_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonabs_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonrech_wadm_clicked(GtkButton *button,
                                gpointer user_data);

void on_hraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_fraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_buttondcnx_wadm_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonvalaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data);

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data);

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_buttonvalmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonretmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonokmod_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretsup_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_lsadmsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_lsempsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_lsouvsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_buttonaff_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonret_wadm_clicked(GtkButton *button,
                               gpointer user_data);

void on_treeviewaff_wadm_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data);

void on_buttonafficher_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretaff_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonsuppr_wadm_clicked(GtkButton *button,
                                 gpointer user_data);

void on_okbuttonsucc_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonquit_clicked(GtkButton *button,
                           gpointer user_data);

void on_buttoncnx_clicked(GtkButton *button,
                          gpointer user_data);

void on_buttondcnx_ea_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttongestion_ea_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonaj_wemp_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonaff_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonmod_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonsup_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonrech_wemp_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonabs_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttonvalaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_fraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_hraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_lsemp_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_lsouv_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_hrmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_frmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data);

void on_buttonvalmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_lsempsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_lsouvsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_buttonretsup_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonsuppr_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonokmod_wemp_clicked(GtkButton *button,
                                 gpointer user_data);

void on_buttonretmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttonafficher_wemp_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretaff_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_okbuttonsucc_wemp_clicked(GtkButton *button,
                                  gpointer user_data);

void on_treeviewaff_wemp_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data);

void on_buttondcnx_wemp_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttonviewaj_wadm_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data);

void on_buttonviewmod_wadm_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data);

void on_buttonview_auth_toggled(GtkToggleButton *togglebutton,
                                gpointer user_data);

void on_buttonviewaj_wemp_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data);

void on_buttonviewmod_wemp_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data);

void on_buttontauxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonmarqabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttondcnxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonretabs_wadm_clicked(GtkButton *button,
                                  gpointer user_data);

void on_lsemabs_wadm_toggled(GtkToggleButton *togglebutton,
                             gpointer user_data);

void on_lsouvabs_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data);

void on_abs_wadm_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data);

void on_pres_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data);

void on_treeviewaffabs_wadm_row_activated(GtkTreeView *treeviewaffabs,
                                          GtkTreePath *path,
                                          GtkTreeViewColumn *column,
                                          gpointer user_data);

void on_buttonretaffabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data);

void on_buttonvalafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonretafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttondateabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_lsemptabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data);

void on_lsouvtabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data);

void on_buttonafftabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data);

void on_buttonretafftabs_wadm_clicked(GtkButton *button,
                                      gpointer user_data);

void on_buttonafficherabs_wadm_clicked(GtkButton *button,
                                       gpointer user_data);

void on_buttonmodafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonsupafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data);

void on_buttonret_wemp_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttongcal_ee_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttongequi_ee_clicked(GtkButton *button,
                               gpointer user_data);

void on_buttongtroup_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttongutils_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttongclients_ee_clicked(GtkButton *button,
                                  gpointer user_data);

void on_buttongcapts_ee_clicked(GtkButton *button,
                                gpointer user_data);

void on_buttondcnx_ee_clicked(GtkButton *button,
                              gpointer user_data);

void on_buttonaffichabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data);

void
on_buttonemp_ea_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonret_gpl_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttondcnx_gpl_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonactu_gpl_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeviewpl_gpl_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_lraj_gpl_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fraj_gpl_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonrejat_gpl_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalaj_gpl_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_frmod_gpl_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_lrmod_gpl_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonokmod_gpl_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalmod_gpl_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalsup_gpl_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonretmod_gpl_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrech_gpl_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaj_gpl_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonmodsup_gpl_clicked            (GtkButton       *button,
                                        gpointer         user_data);
