#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "gestionPl.h"

//Definition des fonctions
/*---------------------------/CONTROLE-SAISIE/---------------------------*/
int verifNumPl(char num[])
{
    int t = 0;
    int i = 0;
    for (i = 0; i < strlen(num); i++)
    {
        if (num[i] >= '0' && num[i] <= '9')
        {
            t = 1;
        }
        else
        {
            return 0;
            break;
        }
    }
    return t;
}

int verifPl(char id[], char fich[])
{
    PLANTE p;
    int test = 0;
    FILE *f1;
    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock) != EOF)
        {
            if ((strcmp(id, p.id) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
    }
    return test;
}

/*---------------------------/C-R-U-D/---------------------------*/
/*---------------------------/TACHE1/---------------------------*/
//Ajout d'une Plante
void ajoutPl(PLANTE p, char fich[])
{
    FILE *f;
    sprintf(p.dtpl, "%d/%d/%d", p.datePl.jour, p.datePl.mois, p.datePl.annee);
    sprintf(p.dtrec, "%d/%d/%d", p.dateRec.jour, p.dateRec.mois, p.dateRec.annee);
    f = fopen(fich, "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock);
        fclose(f);
    }
}

//Modification des informations
void modifPl(PLANTE m, char id[], char fich[])
{
    PLANTE u;
    FILE *f1 = NULL, *f = NULL;
    sprintf(m.dtpl, "%d/%d/%d", m.datePl.jour, m.datePl.mois, m.datePl.annee);
    sprintf(m.dtrec, "%d/%d/%d", m.dateRec.jour, m.dateRec.mois, m.dateRec.annee);
    sprintf(u.dtpl, "%d/%d/%d", u.datePl.jour, u.datePl.mois, u.datePl.annee);
    sprintf(u.dtrec, "%d/%d/%d", u.dateRec.jour, u.dateRec.mois, u.dateRec.annee);
    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if ((f != NULL) && (f1 != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock) != EOF)
        {
            if (strcmp(id, u.id) != 0)
            {
                fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock);
            }
            else
            {
                fprintf(f1, "%s %s %s %s %s %s %s \n", m.id, m.var, m.type, m.recolte, m.dtpl, m.dtrec, m.stock);
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Suppression d'une Plante
void suppPl(char id[], char fich[])
{
    PLANTE u;
    FILE *f1 = NULL, *f = NULL;

    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock) != EOF)
        {
            if (f1 != NULL)
            {
                if (strcmp(u.id, id) != 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock);
                }
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Recherche des informations d'une Plante
PLANTE rechPl(char id[], char fich[])
{
    FILE *f = NULL;
    PLANTE p;
    //sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
    f = fopen(fich, "r");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock) != EOF)
        {
            if (strcmp(id, p.id) == 0)
            {
                return p;
            }
        }
    }
    fclose(f);
}