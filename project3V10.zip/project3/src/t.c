//#include <stdio.h>
#include <stdio.h>
#include <string.h>
typedef struct
{
    int jour, mois, annee;

} DATE;
typedef struct
{
    char cin[50];
    char pw[50];

} LOGIN;

typedef struct
{
    LOGIN log;
    char nom[50];
    char prenom[50];
    char dateNaiss[50];
    char numTel[50];
    char sexe[50];
    char role[50];
    DATE date;

} UTILISATEUR;
int main(int argc, char const *argv[])
{
    UTILISATEUR u;
    FILE *f1;
    int lignes = 0;
    int test = 0;
    f1 = fopen("users.txt", "r");

    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            lignes++;
            if ((strcmp(u.log.cin, "12345677") == 0))
            {
                test = lignes;
            }
        }
        fclose(f1);
    }

    printf("Ligne : %d\n", test - 1);

    return 0;
}
