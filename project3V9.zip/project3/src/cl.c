CLIENT rechPl(CLIENT u)
{
    FILE *f = NULL;
    CLIENT c;
    //sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
    f = fopen(fich, "a+");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", p.id, p.cat, p.type, p.recolte, p.stock, p.dtpl, p.dtrec) != EOF)
        {
            if (strcmp(u.id, p.id) == 0)
            {
                return c;
            }
        }
    }
    fclose(f);
}