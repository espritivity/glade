#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <gtk/gtk.h>
#include "gestionUtils.h"
#include "gestionPl.h"
#include "callbacks.h"
#include "interface.h"
#include "support.h"

/*#######################/GESTION DES UTILISATEURS/#######################*/
int sexeaj_wadm, sexemod_wadm, rolemod_wadm, rolesup_wadm;
int sexeaj_wemp, sexemod_wemp, rolemod_wemp, rolesup_wemp;
int roleabs_wadm, roletabs_wadm, presabs_wadm;
int varaj, varmod;
void on_buttoncnx_clicked(GtkButton *button,
                          gpointer user_data)
{
    char fich[20], cinrole[20];
    strcpy(fich, "users.txt");
    UTILISATEUR a;
    FILE *f1;
    int test = 0;
    GtkWidget *login, *mdp;
    GtkWidget *EspaceAdmin, *InterEmp, *Authentification;
    GtkWidget *output;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    login = lookup_widget(button, "entryLogin");
    mdp = lookup_widget(button, "entryMdp");
    output = lookup_widget(button, "hwlabelauth");

    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", a.log.cin, a.log.pw, a.nom, a.prenom, a.dateNaiss, a.numTel, a.sexe, a.role) != EOF)
        {
            if ((strcmp(a.log.cin, gtk_entry_get_text(GTK_ENTRY(login))) == 0) && (strcmp(a.log.pw, gtk_entry_get_text(GTK_ENTRY(mdp))) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
    }
    if (!test)
    {
        sprintf(msg, "Login ou mot de passe incorrect !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        f1 = fopen(fich, "r");
        strcpy(cinrole, gtk_entry_get_text(GTK_ENTRY(login)));
        if (f1 != NULL)
        {
            while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", a.log.cin, a.log.pw, a.nom, a.prenom, a.dateNaiss, a.numTel, a.sexe, a.role) != EOF)
            {
                if ((strcmp(cinrole, a.log.cin) == 0))
                {
                    if ((strcmp(a.role, "Admin") == 0))
                    {
                        Authentification = lookup_widget(button, "Authentification");
                        gtk_widget_destroy(Authentification);
                        EspaceAdmin = lookup_widget(button, "EspaceAdmin");
                        EspaceAdmin = create_EspaceAdmin();
                        gtk_window_set_position(GTK_WINDOW(EspaceAdmin), GTK_WIN_POS_CENTER_ALWAYS);
                        gtk_widget_show(EspaceAdmin);
                    }
                    else if ((strcmp(a.role, "Employe")) == 0)
                    {
                        Authentification = lookup_widget(button, "Authentification");
                        gtk_widget_destroy(Authentification);
                        InterEmp = lookup_widget(button, "InterEmp");
                        InterEmp = create_InterEmp();
                        gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
                        gtk_widget_show(InterEmp);
                    }
                }
            }
        }
        fclose(f1);
    }
}
void on_buttonquit_clicked(GtkButton *button,
                           gpointer user_data)
{
    gtk_main_quit();
}

void on_buttonaj_wadm_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *ajout_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    ajout_wadm = lookup_widget(button, "ajout_wadm");
    ajout_wadm = create_ajout_wadm();
    gtk_window_set_position(GTK_WINDOW(ajout_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_wadm);
}

void on_buttonmod_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *modif_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    modif_wadm = lookup_widget(button, "modif_wadm");
    modif_wadm = create_modif_wadm();
    gtk_window_set_position(GTK_WINDOW(modif_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modif_wadm);
}

void on_buttonrech_wadm_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20], rech[20], cin[20];
    strcpy(fich, "users.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *aff_wadm, *treeview;
    UTILISATEUR u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wadm = lookup_widget(button, "aff_wadm");
    cinrech = lookup_widget(button, "rech_wadm");
    output = lookup_widget(button, "outputrech_wadm");

    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if (strcmp(cin, u.log.cin) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_wadm);
        treeview = lookup_widget(aff_wadm, "treeviewaff_wadm");
        affUtils(treeview, rech);
        remove("rech.txt");
    }
}

void on_buttondcnx_wadm_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *Authentification;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonvalaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *output_ajout;
    GtkWidget *ajout_wadm, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_wadm");

    cin = lookup_widget(button, "cinaj_wadm");
    nom = lookup_widget(button, "nomaj_wadm");
    prenom = lookup_widget(button, "pnomaj_wadm");
    pw = lookup_widget(button, "pwaj_wadm");
    numtel = lookup_widget(button, "numtelaj_wadm");
    role = lookup_widget(button, "cbroleaj_wadm");
    jour = lookup_widget(button, "spinjaj_wadm");
    mois = lookup_widget(button, "spinmaj_wadm");
    annee = lookup_widget(button, "spinaaj_wadm");

    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifUtils(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "L'utilisateur existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.log.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexeaj_wadm == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexeaj_wadm == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutUtils(u, fich);
        ajout_wadm = lookup_widget(button, "ajout_wadm");
        //gtk_widget_destroy(ajout_wadm);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Utilisateur ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretaj_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *ajout_wadm;

    ajout_wadm = lookup_widget(button, "ajout_wadm");
    gtk_widget_destroy(ajout_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_buttonvalmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *ad, *admin, *emp, *employe, *ouv, *ouvrier;
    GtkWidget *output_modif;
    GtkWidget *modif_wadm, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    modif_wadm = lookup_widget(button, "modif_wadm");
    output_modif = lookup_widget(button, "outputmod_wadm");

    nom = lookup_widget(button, "nommod_wadm");
    prenom = lookup_widget(button, "prnommod_wadm");
    pw = lookup_widget(button, "pwmod_wadm");
    numtel = lookup_widget(button, "numtelmod_wadm");
    role = lookup_widget(button, "cbrolemod_wadm");
    jour = lookup_widget(button, "spinjmod_wadm");
    mois = lookup_widget(button, "spinmmod_wadm");
    annee = lookup_widget(button, "spinamod_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");

    if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexemod_wadm == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexemod_wadm == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        modifUtils(u, u.log.cin, fich);
        modif_wadm = lookup_widget(button, "modif_wadm");
        //gtk_widget_destroy(modif_wadm);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Modification effectuee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretmod_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *modif_wadm;

    modif_wadm = lookup_widget(button, "modif_wadm");
    gtk_widget_destroy(modif_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_buttonokmod_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *nom, *prenom, *pw, *numtel, *role, *jour, *mois, *annee, *admin, *employe, *ouvrier, *homme, *femme;
    GtkWidget *ad, *emp, *ouv;
    GtkWidget *output_modif;
    UTILISATEUR u;
    char fich[20];
    strcpy(fich, "users.txt");

    output_modif = lookup_widget(button, "outputmod_wadm");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    nom = lookup_widget(button, "nommod_wadm");
    prenom = lookup_widget(button, "prnommod_wadm");
    pw = lookup_widget(button, "pwmod_wadm");
    numtel = lookup_widget(button, "numtelmod_wadm");
    role = lookup_widget(button, "cbrolemod_wadm");
    jour = lookup_widget(button, "spinjmod_wadm");
    mois = lookup_widget(button, "spinmmod_wadm");
    annee = lookup_widget(button, "spinamod_wadm");
    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");
    homme = lookup_widget(button, "hrmod_wadm");
    femme = lookup_widget(button, "frmod_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 0);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 1);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 2);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
}
void on_buttonsuppr_wadm_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    char cinsup[50];
    UTILISATEUR u;
    GtkWidget *ad, *admin, *emp, *employe, *ouvrier, *ouv;
    GtkWidget *succ_wadm, *msg_succ;

    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    admin = lookup_widget(button, "cbadmmodif_wadm");
    employe = lookup_widget(button, "cbempmodif_wadm");
    ouvrier = lookup_widget(button, "cbouvmodif_wadm");
    ad = lookup_widget(button, "lsadms_wadm");
    emp = lookup_widget(button, "lsemp_wadm");
    ouv = lookup_widget(button, "lsouv_wadm");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    suppUtils(cinsup, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Utilisateur supprimé!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_hraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wadm = 1;
    }
}

void on_fraj_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wadm = 2;
    }
}
void on_lsouv_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 3;
    }
}

void on_lsemp_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 2;
    }
}

void on_lsadms_wadm_toggled(GtkToggleButton *togglebutton,
                            gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wadm = 1;
    }
}

void on_hrmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wadm = 1;
    }
}

void on_frmod_wadm_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wadm = 2;
    }
}

void on_lsadmsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 1;
    }
}

void on_lsempsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 2;
    }
}

void on_lsouvsup_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wadm = 3;
    }
}

void on_buttonaff_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *aff_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    aff_wadm = lookup_widget(button, "aff_wadm");
    aff_wadm = create_aff_wadm();
    gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wadm);
}

void on_buttonret_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *EspaceAdmin;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    EspaceAdmin = create_EspaceAdmin();
    gtk_window_set_position(GTK_WINDOW(EspaceAdmin), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceAdmin);
}

void on_treeviewaff_wadm_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data)
{
    GtkTreeIter iter;
    GtkWidget *aff_wadm, *modif_wadm;
    gchar *cin, *pw, *nom, *prenom, *dateNaiss, *numtel, *sexe, *role;
    GtkWidget *CIN, *PW, *NOM, *PRENOM, *JOUR, *MOIS, *ANNEE, *NUMTEL, *HOMME, *FEMME, *ROLE, *AD, *EMP, *OUV;
    GtkWidget *CBAD, *CBEMP, *CBOUV;
    UTILISATEUR u;
    aff_wadm = lookup_widget(treeview, "aff_wadm");
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &pw, 2, &nom, 3, &prenom, 4, &dateNaiss, 5, &numtel, 6, &sexe, 7, &role, -1);
        strcpy(u.log.cin, cin);
        strcpy(u.log.pw, pw);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(u.dateNaiss, dateNaiss);
        strcpy(u.numTel, numtel);
        strcpy(u.sexe, sexe);
        strcpy(u.role, role);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);

        modif_wadm = create_modif_wadm();
        gtk_widget_hide(aff_wadm);
        gtk_window_set_position(GTK_WINDOW(modif_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modif_wadm);

        NOM = lookup_widget(modif_wadm, "nommod_wadm");
        PRENOM = lookup_widget(modif_wadm, "prnommod_wadm");
        ROLE = lookup_widget(modif_wadm, "cbrolemod_wadm");
        JOUR = lookup_widget(modif_wadm, "spinjmod_wadm");
        MOIS = lookup_widget(modif_wadm, "spinmmod_wadm");
        ANNEE = lookup_widget(modif_wadm, "spinamod_wadm");
        NUMTEL = lookup_widget(modif_wadm, "numtelmod_wadm");
        PW = lookup_widget(modif_wadm, "pwmod_wadm");
        HOMME = lookup_widget(modif_wadm, "hrmod_wadm");
        FEMME = lookup_widget(modif_wadm, "frmod_wadm");
        AD = lookup_widget(modif_wadm, "lsadms_wadm");
        EMP = lookup_widget(modif_wadm, "lsemp_wadm");
        OUV = lookup_widget(modif_wadm, "lsouv_wadm");
        CBAD = lookup_widget(modif_wadm, "cbadmmodif_wadm");
        CBEMP = lookup_widget(modif_wadm, "cbempmodif_wadm");
        CBOUV = lookup_widget(modif_wadm, "cbouvmodif_wadm");

        gtk_entry_set_text(GTK_ENTRY(NOM), nom);
        gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
        gtk_entry_set_text(GTK_ENTRY(CIN), cin);
        gtk_entry_set_text(GTK_ENTRY(PW), pw);
        gtk_entry_set_text(GTK_ENTRY(NUMTEL), numtel);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
        }
        if ((strcmp(u.role, "Admin") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 0);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(CBAD), 0, u.log.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBAD), 0);
        }
        else if ((strcmp(u.role, "Employe") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 1);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(CBEMP), 0, u.log.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBEMP), 0);
        }
        else if ((strcmp(u.role, "Ouvrier") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(AD), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 1);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 2);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(CBOUV), 0, u.log.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBOUV), 0);
        }
    }
}

void on_buttonafficher_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *treeview, *gestionUtils, *aff_wadm;
    GtkWidget *affrole;
    char fich[20];
    UTILISATEUR u;
    aff_wadm = lookup_widget(button, "aff_wadm");
    affrole = lookup_widget(button, "cbaff_wadm");

    FILE *f = NULL, *fa = NULL, *fe = NULL, *fo = NULL;
    f = fopen("users.txt", "r");
    fa = fopen("admins.txt", "w");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");
    if ((f != NULL) && (fa != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if (strcmp(u.role, "Admin") == 0)
            {
                fprintf(fa, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            else if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            else if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(fa);
    fclose(fe);
    fclose(fo);
    if (strcmp("Tous", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "users.txt");
    }
    else if (strcmp("Admins", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "admins.txt");
    }
    else if (strcmp("Employes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "employes.txt");
    }
    else if (strcmp("Ouvriers", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "ouvriers.txt");
    }
    //gtk_widget_destroy(aff_wadm);
    //aff_wadm = create_aff_wadm();
    gtk_window_set_position(GTK_WINDOW(aff_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wadm);
    treeview = lookup_widget(aff_wadm, "treeviewaff_wadm");
    affUtils(treeview, fich);
    remove("admins.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
}

void on_buttonretaff_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *aff_wadm;

    aff_wadm = lookup_widget(button, "aff_wadm");
    gtk_widget_destroy(aff_wadm);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}

void on_okbuttonsucc_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *succ_wadm;

    succ_wadm = lookup_widget(button, "succ_wadm");
    gtk_widget_destroy(succ_wadm);

    //gestionUtils = lookup_widget(button, "gestionUtils");
    //gestionUtils = create_gestionUtils();
    // gtk_widget_show(gestionUtils);
}

void on_buttondcnx_ea_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *Authentification;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttongestion_ea_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *gestionUtils;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    gestionUtils = lookup_widget(button, "gestionUtils");
    gestionUtils = create_gestionUtils();
    gtk_window_set_position(GTK_WINDOW(gestionUtils), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionUtils);
}
void on_buttonemp_ea_clicked(GtkButton *button,
                             gpointer user_data)
{
    GtkWidget *EspaceAdmin;
    GtkWidget *InterEmp;

    EspaceAdmin = lookup_widget(button, "EspaceAdmin");
    gtk_widget_destroy(EspaceAdmin);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}
void on_buttonaj_wemp_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *ajout_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    ajout_wemp = lookup_widget(button, "ajout_wemp");
    ajout_wemp = create_ajout_wemp();
    gtk_window_set_position(GTK_WINDOW(ajout_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_wemp);
}

void on_buttonaff_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *aff_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    aff_wemp = lookup_widget(button, "aff_wemp");
    aff_wemp = create_aff_wemp();
    gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wemp);
}

void on_buttonmod_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *modif_wemp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    modif_wemp = lookup_widget(button, "modif_wemp");
    modif_wemp = create_modif_wemp();
    gtk_window_set_position(GTK_WINDOW(modif_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modif_wemp);
}

void on_buttonrech_wemp_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20], rech[20], cin[20];
    strcpy(fich, "users.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *aff_wemp, *treeview;
    UTILISATEUR u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_wemp = lookup_widget(button, "aff_wemp");
    cinrech = lookup_widget(button, "rech_wemp");
    output = lookup_widget(button, "outputrech_wemp");

    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if ((strcmp(cin, u.log.cin) == 0) && (strcmp(u.role, "Admin") != 0))
                {
                    fprintf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_wemp);
        treeview = lookup_widget(aff_wemp, "treeviewaff_wemp");
        affUtils(treeview, rech);
        remove("rech.txt");
    }
}

void on_buttonvalaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *output_ajout;
    GtkWidget *ajout_wemp, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_wemp");

    cin = lookup_widget(button, "cinaj_wemp");
    nom = lookup_widget(button, "nomaj_wemp");
    prenom = lookup_widget(button, "pnomaj_wemp");
    pw = lookup_widget(button, "pwaj_wemp");
    numtel = lookup_widget(button, "numtelaj_wemp");
    role = lookup_widget(button, "cbroleaj_wemp");
    jour = lookup_widget(button, "spinjaj_wemp");
    mois = lookup_widget(button, "spinmaj_wemp");
    annee = lookup_widget(button, "spinaaj_wemp");

    if (!verifCin(gtk_entry_get_text(GTK_ENTRY(cin))))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifUtils(gtk_entry_get_text(GTK_ENTRY(cin)), fich))
    {
        sprintf(msg, "L'utilisateur existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(u.log.cin, gtk_entry_get_text(GTK_ENTRY(cin)));
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexeaj_wemp == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexeaj_wemp == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        ajoutUtils(u, fich);
        ajout_wemp = lookup_widget(button, "ajout_wemp");
        //gtk_widget_destroy(ajout_wemp);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Utilisateur ajouté avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonretaj_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *ajout_wemp;

    ajout_wemp = lookup_widget(button, "ajout_wemp");
    gtk_widget_destroy(ajout_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_fraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wemp = 2;
    }
}

void on_hraj_wemp_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexeaj_wemp = 1;
    }
}

void on_lsemp_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wemp = 1;
    }
}

void on_hrmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wemp = 1;
    }
}

void on_frmod_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        sexemod_wemp = 2;
    }
}

void on_buttonvalmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    UTILISATEUR u;
    GtkWidget *cin, *nom, *prenom, *pw, *numtel, *jour, *mois, *annee, *role;
    GtkWidget *ad, *admin, *emp, *employe, *ouv, *ouvrier;
    GtkWidget *output_modif;
    GtkWidget *modif_wemp, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    modif_wemp = lookup_widget(button, "modif_wemp");
    output_modif = lookup_widget(button, "outputmod_wemp");

    nom = lookup_widget(button, "nommod_wemp");
    prenom = lookup_widget(button, "prnommod_wemp");
    pw = lookup_widget(button, "pwmod_wemp");
    numtel = lookup_widget(button, "numtelmod_wemp");
    role = lookup_widget(button, "cbrolemod_wemp");
    jour = lookup_widget(button, "spinjmod_wemp");
    mois = lookup_widget(button, "spinmmod_wemp");
    annee = lookup_widget(button, "spinamod_wemp");

    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");

    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");

    if (verifNum(gtk_entry_get_text(GTK_ENTRY(nom))))
    {
        sprintf(msg, "Le nom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if ((verifNum(gtk_entry_get_text(GTK_ENTRY(prenom)))))
    {
        sprintf(msg, "Le prénom ne doit pas avoir des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifCin(gtk_entry_get_text(GTK_ENTRY(numtel))))
    {
        sprintf(msg, "Le numero telephonique doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(u.log.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
        strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
        strcpy(u.log.pw, gtk_entry_get_text(GTK_ENTRY(pw)));
        strcpy(u.numTel, gtk_entry_get_text(GTK_ENTRY(numtel)));
        strcpy(u.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(role)));

        suppEspaces(u.nom);
        suppEspaces(u.prenom);

        u.date.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        u.date.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        u.date.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        strcpy(u.sexe, "Homme");
        if (sexemod_wemp == 1)
        {
            strcpy(u.sexe, "Homme");
        }
        else if (sexemod_wemp == 2)
        {
            strcpy(u.sexe, "Femme");
        }
        modifUtils(u, u.log.cin, fich);
        modif_wemp = lookup_widget(button, "modif_wemp");
        // gtk_widget_destroy(modif_wemp);
        succ_wadm = lookup_widget(button, "succ_wadm");
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Modification effectuee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_lsouv_wemp_toggled(GtkToggleButton *togglebutton,
                           gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolemod_wemp = 2;
    }
}

void on_lsempsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wemp = 1;
    }
}

void on_lsouvsup_wemp_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        rolesup_wemp = 2;
    }
}

void on_buttonsuppr_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "users.txt");
    char cinsup[50];
    UTILISATEUR u;
    GtkWidget *ad, *admin, *emp, *employe, *ouvrier, *ouv;
    GtkWidget *succ_wadm, *msg_succ;

    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    admin = lookup_widget(button, "cbadmmodif_wemp");
    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");
    ad = lookup_widget(button, "lsadms_wemp");
    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ad)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(admin)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    suppUtils(cinsup, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Utilisateur supprimé!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonokmod_wemp_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *nom, *prenom, *pw, *numtel, *role, *jour, *mois, *annee, *admin, *employe, *ouvrier, *homme, *femme;
    GtkWidget *ad, *emp, *ouv;
    GtkWidget *output_modif;
    UTILISATEUR u;
    char fich[20];
    strcpy(fich, "users.txt");

    output_modif = lookup_widget(button, "outputmod_wemp");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    nom = lookup_widget(button, "nommod_wemp");
    prenom = lookup_widget(button, "prnommod_wemp");
    pw = lookup_widget(button, "pwmod_wemp");
    numtel = lookup_widget(button, "numtelmod_wemp");
    role = lookup_widget(button, "cbrolemod_wemp");
    jour = lookup_widget(button, "spinjmod_wemp");
    mois = lookup_widget(button, "spinmmod_wemp");
    annee = lookup_widget(button, "spinamod_wemp");

    employe = lookup_widget(button, "cbempmodif_wemp");
    ouvrier = lookup_widget(button, "cbouvmodif_wemp");
    homme = lookup_widget(button, "hrmod_wemp");
    femme = lookup_widget(button, "frmod_wemp");

    emp = lookup_widget(button, "lsemp_wemp");
    ouv = lookup_widget(button, "lsouv_wemp");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 0);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        u = rechUtils(gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)), fich);
        gtk_combo_box_set_active(GTK_COMBO_BOX(role), 1);
        gtk_entry_set_text(GTK_ENTRY(nom), u.nom);
        gtk_entry_set_text(GTK_ENTRY(prenom), u.prenom);
        gtk_entry_set_text(GTK_ENTRY(pw), u.log.pw);
        gtk_entry_set_text(GTK_ENTRY(numtel), u.numTel);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(homme), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(femme), 1);
        }
    }
}

void on_buttonretmod_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *modif_wemp;

    modif_wemp = lookup_widget(button, "modif_wemp");
    gtk_widget_destroy(modif_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_buttonafficher_wemp_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *treeview, *gestionUtils, *aff_wemp;
    GtkWidget *affrole;
    char fich[20];
    UTILISATEUR u;
    aff_wemp = lookup_widget(button, "aff_wemp");
    affrole = lookup_widget(button, "cbaff_wemp");

    FILE *f = NULL, *ft = NULL, *fe = NULL, *fo = NULL;
    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");
    ft = fopen("empouv.txt", "w");
    if ((f != NULL) && (ft != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
            {
                fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Employe") == 0)
            {
                fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
            if (strcmp(u.role, "Ouvrier") == 0)
            {
                fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
            }
        }
    }
    fclose(f);
    fclose(ft);
    fclose(fe);
    fclose(fo);
    if (strcmp("Tous", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "empouv.txt");
    }
    else if (strcmp("Employes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "employes.txt");
    }
    else if (strcmp("Ouvriers", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "ouvriers.txt");
    }
    //gtk_widget_destroy(aff_wemp);
    //aff_wemp = create_aff_wemp();
    gtk_window_set_position(GTK_WINDOW(aff_wemp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_wemp);
    treeview = lookup_widget(aff_wemp, "treeviewaff_wemp");
    affUtils(treeview, fich);
    remove("admins.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
    remove("empouv.txt");
}

void on_buttonretaff_wemp_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *aff_wemp;

    aff_wemp = lookup_widget(button, "aff_wemp");
    gtk_widget_destroy(aff_wemp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_treeviewaff_wemp_row_activated(GtkTreeView *treeview,
                                       GtkTreePath *path,
                                       GtkTreeViewColumn *column,
                                       gpointer user_data)
{
    GtkTreeIter iter;
    GtkWidget *aff_wemp, *modif_wemp;
    gchar *cin, *pw, *nom, *prenom, *dateNaiss, *numtel, *sexe, *role;
    GtkWidget *CIN, *PW, *NOM, *PRENOM, *JOUR, *MOIS, *ANNEE, *NUMTEL, *HOMME, *FEMME, *ROLE, *AD, *EMP, *OUV;
    GtkWidget *CBAD, *CBEMP, *CBOUV;
    UTILISATEUR u;
    aff_wemp = lookup_widget(treeview, "aff_wemp");
    GtkTreeModel *model = gtk_tree_view_get_model(treeview);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &pw, 2, &nom, 3, &prenom, 4, &dateNaiss, 5, &numtel, 6, &sexe, 7, &role, -1);
        strcpy(u.log.cin, cin);
        strcpy(u.log.pw, pw);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(u.dateNaiss, dateNaiss);
        strcpy(u.numTel, numtel);
        strcpy(u.sexe, sexe);
        strcpy(u.role, role);
        sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);

        modif_wemp = create_modif_wemp();
        gtk_widget_hide(aff_wemp);
        gtk_window_set_position(GTK_WINDOW(modif_wemp), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modif_wemp);

        NOM = lookup_widget(modif_wemp, "nommod_wemp");
        PRENOM = lookup_widget(modif_wemp, "prnommod_wemp");
        ROLE = lookup_widget(modif_wemp, "cbrolemod_wemp");
        JOUR = lookup_widget(modif_wemp, "spinjmod_wemp");
        MOIS = lookup_widget(modif_wemp, "spinmmod_wemp");
        ANNEE = lookup_widget(modif_wemp, "spinamod_wemp");
        NUMTEL = lookup_widget(modif_wemp, "numtelmod_wemp");
        PW = lookup_widget(modif_wemp, "pwmod_wemp");
        HOMME = lookup_widget(modif_wemp, "hrmod_wemp");
        FEMME = lookup_widget(modif_wemp, "frmod_wemp");

        EMP = lookup_widget(modif_wemp, "lsemp_wemp");
        OUV = lookup_widget(modif_wemp, "lsouv_wemp");

        CBEMP = lookup_widget(modif_wemp, "cbempmodif_wemp");
        CBOUV = lookup_widget(modif_wemp, "cbouvmodif_wemp");

        gtk_entry_set_text(GTK_ENTRY(NOM), nom);
        gtk_entry_set_text(GTK_ENTRY(PRENOM), prenom);
        gtk_entry_set_text(GTK_ENTRY(CIN), cin);
        gtk_entry_set_text(GTK_ENTRY(PW), pw);
        gtk_entry_set_text(GTK_ENTRY(NUMTEL), numtel);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(JOUR), u.date.jour);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(MOIS), u.date.mois);
        gtk_spin_button_set_value(GTK_SPIN_BUTTON(ANNEE), u.date.annee);
        if ((strcmp(u.sexe, "Homme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 0);
        }
        else if ((strcmp(u.sexe, "Femme") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(HOMME), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(FEMME), 1);
        }
        if ((strcmp(u.role, "Employe") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 0);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 0);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(CBEMP), 0, u.log.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBEMP), 0);
        }
        else if ((strcmp(u.role, "Ouvrier") == 0))
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(EMP), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(OUV), 1);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ROLE), 1);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(CBOUV), 0, u.log.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(CBOUV), 0);
        }
    }
}
void on_buttondcnx_wemp_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *Authentification;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonviewaj_wadm_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data)
{
    GtkWidget *pwaj_wadm;
    pwaj_wadm = lookup_widget(GTK_WIDGET(togglebutton), "pwaj_wadm");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wadm), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wadm), FALSE);
}

void on_buttonviewmod_wadm_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data)
{
    GtkWidget *pwmod_wadm;
    pwmod_wadm = lookup_widget(GTK_WIDGET(togglebutton), "pwmod_wadm");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wadm), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wadm), FALSE);
}

void on_buttonview_auth_toggled(GtkToggleButton *togglebutton,
                                gpointer user_data)
{
    GtkWidget *entryMdp;
    entryMdp = lookup_widget(GTK_WIDGET(togglebutton), "entryMdp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(entryMdp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(entryMdp), FALSE);
}

void on_buttonviewaj_wemp_toggled(GtkToggleButton *togglebutton,
                                  gpointer user_data)
{
    GtkWidget *pwaj_wemp;
    pwaj_wemp = lookup_widget(GTK_WIDGET(togglebutton), "pwaj_wemp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wemp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwaj_wemp), FALSE);
}

void on_buttonviewmod_wemp_toggled(GtkToggleButton *togglebutton,
                                   gpointer user_data)
{
    GtkWidget *pwmod_wemp;
    pwmod_wemp = lookup_widget(GTK_WIDGET(togglebutton), "pwmod_wemp");
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wemp), TRUE);
    else
        gtk_entry_set_visibility(GTK_ENTRY(pwmod_wemp), FALSE);
}

/*#######################/GESTION DES ABSENCES/#######################*/
void on_buttonabs_wadm_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionUtils;
    GtkWidget *gestionAbs_wadm;

    gestionUtils = lookup_widget(button, "gestionUtils");
    gtk_widget_destroy(gestionUtils);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}
void on_buttonabs_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *gestionAbs_wadm;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttonmarqabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *marqAbs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    marqAbs_wadm = lookup_widget(button, "marqAbs_wadm");
    marqAbs_wadm = create_marqAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(marqAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(marqAbs_wadm);
}
void on_buttonaffichabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *affabs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    affabs_wadm = create_affabs_wadm();
    gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(affabs_wadm);
}
void on_buttontauxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *tauxabs_wadm;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    tauxabs_wadm = lookup_widget(button, "tauxabs_wadm");
    tauxabs_wadm = create_tauxabs_wadm();
    gtk_window_set_position(GTK_WINDOW(tauxabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(tauxabs_wadm);
}

void on_buttondateabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *jour, *mois, *annee;
    OUVRIER o;
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    o = dateAuj(o);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour), o.dateAbs.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois), o.dateAbs.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(annee), o.dateAbs.annee);
}
void on_buttonvalafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    OUVRIER o;
    FILE *f1;
    GtkWidget *emp, *employe, *ouv, *ouvrier, *jour, *mois, *annee, *abs, *pres, *valAbs;
    GtkWidget *output;
    int j, m, a;
    char date[100];
    int test = 0;

    output = lookup_widget(button, "outputabs_wadm");
    emp = lookup_widget(button, "lsemabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    abs = lookup_widget(button, "abs_wadm");
    pres = lookup_widget(button, "pres_wadm");

    j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    sprintf(date, "%d/%d/%d", j, m, a);

    f1 = fopen(fich, "a+");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s\n", o.logAbs.cin, o.date, o.valAbs, o.roleAbs) != EOF)
        {
            if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
            {
                if ((strcmp(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe))) == 0) && (strcmp(o.date, date)) == 0)
                {
                    test = 1;
                }
            }
            else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
            {
                if ((strcmp(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier))) == 0) && (strcmp(o.date, date)) == 0)
                {
                    test = 1;
                }
            }
        }
    }
    fclose(f1);
    if (test)
    {
        sprintf(msg, "Absence déjà affectée !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
        {
            strcpy(o.roleAbs, "Employe");
            strcpy(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
        {
            strcpy(o.roleAbs, "Ouvrier");
            strcpy(o.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        }
        o.dateAbs.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
        o.dateAbs.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
        o.dateAbs.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
        sprintf(o.date, "%d/%d/%d", o.dateAbs.jour, o.dateAbs.mois, o.dateAbs.annee);
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(abs)))
        {
            strcpy(o.valAbs, "Absent");
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(pres)))
        {
            strcpy(o.valAbs, "Present");
        }
        marquerAbs(o, fich);
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        sprintf(msg, "Absence affectee avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
}

void on_buttonretafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *marqAbs_wadm;
    marqAbs_wadm = lookup_widget(button, "marqAbs_wadm");
    gtk_widget_destroy(marqAbs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttondcnxabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *Authentification;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonretabs_wadm_clicked(GtkButton *button,
                                  gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *EspaceEmp;

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gtk_widget_destroy(gestionAbs_wadm);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}

void on_lsemabs_wadm_toggled(GtkToggleButton *togglebutton,
                             gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roleabs_wadm = 1;
    }
}

void on_lsouvabs_wadm_toggled(GtkToggleButton *togglebutton,
                              gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roleabs_wadm = 2;
    }
}

void on_abs_wadm_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        presabs_wadm = 0;
    }
}

void on_pres_wadm_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        presabs_wadm = 1;
    }
}

void on_treeviewaffabs_wadm_row_activated(GtkTreeView *treeviewaffabs,
                                          GtkTreePath *path,
                                          GtkTreeViewColumn *column,
                                          gpointer user_data)
{
    GtkTreeIter iter;
    gchar *cin, *nom, *prenom, *jtrav, *jabs, *taux;
    GtkWidget *affabs_wadm, *tauxabs_wadm;
    GtkWidget *emp, *employe, *ouv, *ouvrier;
    OUVRIER o;
    UTILISATEUR u;
    int role;
    FILE *f1;
    char fich[20];
    affabs_wadm = lookup_widget(treeviewaffabs, "affabs_wadm");
    GtkTreeModel *model = gtk_tree_view_get_model(treeviewaffabs);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &cin, 1, &nom, 2, &prenom, 3, &jtrav, 4, &jabs, 5, &taux, -1);
        strcpy(o.logAbs.cin, cin);
        strcpy(u.nom, nom);
        strcpy(u.prenom, prenom);
        strcpy(o.jtrav, jtrav);
        strcpy(o.jabs, jabs);
        strcpy(o.taux, taux);
        f1 = fopen("users.txt", "r");
        if (f1 != NULL)
        {
            while (fscanf(f1, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if (strcmp(u.log.cin, o.logAbs.cin) == 0)
                {
                    if ((strcmp(u.role, "Employe")) == 0)
                    {
                        role = 1;
                    }
                    else if ((strcmp(u.role, "Ouvrier")) == 0)
                    {
                        role = 2;
                    }
                }
            }
        }
        fclose(f1);
        tauxabs_wadm = create_tauxabs_wadm();
        gtk_widget_hide(affabs_wadm);
        gtk_window_set_position(GTK_WINDOW(tauxabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(tauxabs_wadm);

        emp = lookup_widget(tauxabs_wadm, "lsemptabs_wadm");
        ouv = lookup_widget(tauxabs_wadm, "lsouvtabs_wadm");

        employe = lookup_widget(tauxabs_wadm, "cbemptaux_wadm");
        ouvrier = lookup_widget(tauxabs_wadm, "cbouvtaux_wadm");

        if (role == 1)
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(emp), 1);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(ouv), 0);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(employe), 0, o.logAbs.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(employe), 0);
        }
        else if (role == 2)
        {
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(emp), 0);
            gtk_toggle_button_set_active(GTK_RADIO_BUTTON(ouv), 1);
            gtk_combo_box_insert_text(GTK_COMBO_BOX(ouvrier), 0, o.logAbs.cin);
            gtk_combo_box_set_active(GTK_COMBO_BOX(ouvrier), 0);
        }
    }
}
void on_buttonafficherabs_wadm_clicked(GtkButton *button,
                                       gpointer user_data)
{
    GtkWidget *treeviewaffabs, *affabs_wadm;
    GtkWidget *affrole;
    char fich1[20], fich2[20], fich3[20];
    OUVRIER o;
    UTILISATEUR u;

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    affrole = lookup_widget(button, "cbaffabs_wadm");

    FILE *f = NULL, *ft = NULL, *fe = NULL, *fo = NULL;
    f = fopen("users.txt", "r");
    fe = fopen("employes.txt", "w");
    fo = fopen("ouvriers.txt", "w");
    ft = fopen("empouv.txt", "w");
    if ((f != NULL) && (ft != NULL) && (fe != NULL) && (fo != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
        {
            if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
            {
                fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);

                if (strcmp(u.role, "Employe") == 0)
                {
                    fprintf(fe, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
                else if (strcmp(u.role, "Ouvrier") == 0)
                {
                    fprintf(fo, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
    }
    fclose(f);
    fclose(ft);
    fclose(fe);
    fclose(fo);
    strcpy(fich2, "absences.txt");
    if (strcmp("Tous", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        tauxAbs("empouv.txt", fich2);
    }
    else if (strcmp("Employes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        tauxAbs("employes.txt", fich2);
    }
    else if (strcmp("Ouvriers", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        tauxAbs("ouvriers.txt", fich2);
    }
    strcpy(fich3, "taux.txt");
    //gtk_widget_destroy(affabs_wadm);
    //affabs_wadm = create_affabs_wadm();
    gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(affabs_wadm);
    treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
    affAbs(treeviewaffabs, fich3);
    remove("empouv.txt");
    remove("employes.txt");
    remove("ouvriers.txt");
    remove("taux.txt");
}

void on_buttonrechabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    char fich[20], rech[20], tx[20], absc[20], cin[20];
    char fich1[20], fich2[20], fich3[20];
    strcpy(fich, "users.txt");
    strcpy(absc, "absences.txt");
    strcpy(tx, "taux.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *cinrech, *output, *affabs_wadm, *treeviewaffabs;
    UTILISATEUR u;
    OUVRIER o;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    affabs_wadm = lookup_widget(button, "affabs_wadm");
    cinrech = lookup_widget(button, "rechabs_wadm");
    output = lookup_widget(button, "outputrechabs_wadm");
    FILE *fu = NULL, *ft = NULL;
    strcpy(cin, gtk_entry_get_text(GTK_ENTRY(cinrech)));
    if (!verifCin(cin))
    {
        sprintf(msg, "Le CIN doit avoir 8 chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else if (!verifUtils(cin, fich))
    {

        sprintf(msg, "L'utilisateur n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        fu = fopen("users.txt", "r");
        ft = fopen("empouv.txt", "w");
        if ((fu != NULL) && (ft != NULL))
        {
            while (fscanf(fu, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role) != EOF)
            {
                if ((strcmp(u.role, "Employe") == 0) || (strcmp(u.role, "Ouvrier") == 0))
                {
                    fprintf(ft, "%s %s %s %s %s %s %s %s \n", u.log.cin, u.log.pw, u.nom, u.prenom, u.dateNaiss, u.numTel, u.sexe, u.role);
                }
            }
        }
        fclose(fu);
        fclose(ft);
        tauxAbs("empouv.txt", absc);
        f = fopen(tx, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s\n", u.log.cin, u.nom, u.prenom, o.jtrav, o.jabs, o.taux) != EOF)
            {
                if (strcmp(cin, u.log.cin) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s\n", u.log.cin, u.nom, u.prenom, o.jtrav, o.jabs, o.taux);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(affabs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(affabs_wadm);
        treeviewaffabs = lookup_widget(affabs_wadm, "treeviewaffabs_wadm");
        affAbs(treeviewaffabs, rech);
        remove("empouv.txt");
        remove("rech.txt");
        remove("taux.txt");
    }
}
void on_buttonretaffabs_wadm_clicked(GtkButton *button,
                                     gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *affabs_wadm;

    affabs_wadm = lookup_widget(button, "affabs_wadm");
    gtk_widget_destroy(affabs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_lsemptabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roletabs_wadm = 1;
    }
}

void on_lsouvtabs_wadm_toggled(GtkToggleButton *togglebutton,
                               gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        roletabs_wadm = 2;
    }
}

void on_buttonafftabs_wadm_clicked(GtkButton *button,
                                   gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinmod[50], dtdeb[50], dtfin[50];
    char msg[50], duree[50], *markup, *markupx;
    const char *format = "<span foreground=\"#C800DE\"><i><b>\%s</b></i></span>";
    const char *formatx = "<span foreground=\"blue\"><u><b>\%s</b></u></span>";
    int jdeb, mdeb, adeb;
    int jfin, mfin, afin;
    OUVRIER m;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *caldeb, *calfin, *output, *tx;
    employe = lookup_widget(button, "cbemptaux_wadm");
    ouvrier = lookup_widget(button, "cbouvtaux_wadm");
    emp = lookup_widget(button, "lsemptabs_wadm");
    ouv = lookup_widget(button, "lsouvtabs_wadm");
    caldeb = lookup_widget(button, "calabsd_wadm");
    calfin = lookup_widget(button, "calabsa_wadm");
    output = lookup_widget(button, "output_afftabs_wadm");
    tx = lookup_widget(button, "tx_wadm");
    gtk_label_set_text(GTK_LABEL(output), "");
    gtk_label_set_text(GTK_LABEL(tx), "");
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }
    gtk_calendar_get_date(GTK_CALENDAR(caldeb), &adeb, &mdeb, &jdeb);
    gtk_calendar_get_date(GTK_CALENDAR(calfin), &afin, &mfin, &jfin);
    sprintf(dtdeb, "%d/%d/%d", jdeb, mdeb + 1, adeb);
    sprintf(dtfin, "%d/%d/%d", jfin, mfin + 1, afin);
    m = calcAbs(m.logAbs.cin, dtdeb, dtfin, fich);
    if (m.ctot == 0)
    {
        format = "<span foreground=\"red\"><u><b>\%s</b></u></span>";
        sprintf(msg, "Aucune information trouvée !");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        sprintf(duree, "Durée : du %s au %s", dtdeb, dtfin);
        markup = g_markup_printf_escaped(format, duree);
        gtk_label_set_markup(GTK_LABEL(output), markup);
        sprintf(msg, "Taux d'absenteisme = %s", m.taux);
        markupx = g_markup_printf_escaped(formatx, msg);
        gtk_label_set_markup(GTK_LABEL(tx), markupx);
    }
}

void on_buttonretafftabs_wadm_clicked(GtkButton *button,
                                      gpointer user_data)
{
    GtkWidget *gestionAbs_wadm;
    GtkWidget *tauxabs_wadm;

    tauxabs_wadm = lookup_widget(button, "tauxabs_wadm");
    gtk_widget_destroy(tauxabs_wadm);

    gestionAbs_wadm = lookup_widget(button, "gestionAbs_wadm");
    gestionAbs_wadm = create_gestionAbs_wadm();
    gtk_window_set_position(GTK_WINDOW(gestionAbs_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionAbs_wadm);
}

void on_buttonmodafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinmod[50];
    OUVRIER m;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *jour, *mois, *annee, *abs, *pres;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"purple\"><b>\%s</b></span>";
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    emp = lookup_widget(button, "lsempabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");
    abs = lookup_widget(button, "abs_wadm");
    pres = lookup_widget(button, "pres_wadm");

    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
        strcpy(m.roleAbs, "Employe");
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(m.logAbs.cin, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
        strcpy(m.roleAbs, "Ouvrier");
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(abs)))
    {
        strcpy(m.valAbs, "Absent");
    }
    else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(pres)))
    {
        strcpy(m.valAbs, "Present");
    }
    m.dateAbs.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m.dateAbs.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    m.dateAbs.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    sprintf(m.date, "%d/%d/%d", m.dateAbs.jour, m.dateAbs.mois, m.dateAbs.annee);

    modifAbs(m, m.logAbs.cin, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Absence modifiée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonsupafabs_wadm_clicked(GtkButton *button,
                                    gpointer user_data)
{
    char fich[20];
    strcpy(fich, "absences.txt");
    char cinsup[50];
    OUVRIER o;
    GtkWidget *emp, *employe, *ouvrier, *ouv, *jour, *mois, *annee;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    int j, m, a;
    char date[100];
    jour = lookup_widget(button, "spinjabs_wadm");
    mois = lookup_widget(button, "spinmabs_wadm");
    annee = lookup_widget(button, "spinaabs_wadm");
    employe = lookup_widget(button, "cbempabs_wadm");
    ouvrier = lookup_widget(button, "cbouvabs_wadm");
    emp = lookup_widget(button, "lsempabs_wadm");
    ouv = lookup_widget(button, "lsouvabs_wadm");

    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(emp)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(employe)));
    }
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(ouv)))
    {
        strcpy(cinsup, gtk_combo_box_get_active_text(GTK_COMBO_BOX(ouvrier)));
    }

    j = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
    m = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
    a = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
    sprintf(date, "%d/%d/%d", j, m, a);

    suppAbs(cinsup, date, fich);
    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Absence supprimée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonret_wemp_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *InterEmp;

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    gtk_widget_destroy(EspaceEmp);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}
void on_buttongutils_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *EspaceEmp;
    GtkWidget *InterEmp;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    EspaceEmp = lookup_widget(button, "EspaceEmp");
    EspaceEmp = create_EspaceEmp();
    gtk_window_set_position(GTK_WINDOW(EspaceEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(EspaceEmp);
}
void on_buttondcnx_ee_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *Authentification;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}
void on_buttongcal_ee_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *gestionPlantation;

    InterEmp = lookup_widget(button, "InterEmp");
    gtk_widget_destroy(InterEmp);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}

void on_buttonret_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *InterEmp;
    GtkWidget *gestionPlantation;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    InterEmp = lookup_widget(button, "InterEmp");
    InterEmp = create_InterEmp();
    gtk_window_set_position(GTK_WINDOW(InterEmp), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(InterEmp);
}

void on_buttondcnx_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *Authentification;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    Authentification = lookup_widget(button, "Authentification");
    Authentification = create_Authentification();
    gtk_window_set_position(GTK_WINDOW(Authentification), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(Authentification);
}

void on_buttonactu_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    GtkWidget *treeviewpl, *aff_gpl;
    GtkWidget *affrole;
    char fich[20];
    PLANTE u;
    aff_gpl = lookup_widget(button, "aff_gpl");
    affrole = lookup_widget(button, "cbtypeaff_gpl");

    FILE *f = NULL, *ff = NULL, *fl = NULL, *ft = NULL;
    f = fopen("plantes.txt", "r");
    ff = fopen("fruits.txt", "w");
    fl = fopen("legumes.txt", "w");
    if ((f != NULL) && (ff != NULL) && (fl != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
        {
            if (strcmp(u.cat, "Fruits") == 0)
            {
                fprintf(ff, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
            }
            else if (strcmp(u.cat, "Legumes") == 0)
            {
                fprintf(fl, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
            }
        }
    }
    fclose(f);
    fclose(ff);
    fclose(fl);
    if (strcmp("Tous", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "plantes.txt");
    }
    else if (strcmp("Fruits", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "fruits.txt");
    }
    else if (strcmp("Legumes", gtk_combo_box_get_active_text(GTK_COMBO_BOX(affrole))) == 0)
    {
        strcpy(fich, "legumes.txt");
    }
    gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_gpl);
    treeviewpl = lookup_widget(aff_gpl, "treeviewpl_gpl");
    affPl(treeviewpl, fich);
    remove("frleg.txt");
    remove("fruits.txt");
    remove("legumes.txt");
}
void on_buttonrech_gpl_clicked(GtkButton *button,
                               gpointer user_data)
{
    char fich[20], rech[20], ID[20];
    strcpy(fich, "plantes.txt");
    strcpy(rech, "rech.txt");
    GtkWidget *idrech, *output, *aff_gpl, *treeviewgpl;
    PLANTE u;
    FILE *f = NULL, *f1 = NULL;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    aff_gpl = lookup_widget(button, "aff_gpl");
    idrech = lookup_widget(button, "rech_gpl");
    output = lookup_widget(button, "outputrech_gpl");

    strcpy(ID, gtk_entry_get_text(GTK_ENTRY(idrech)));
    suppEspaces(ID);
    if (!verifPl(ID, fich))
    {

        sprintf(msg, "La plante n'existe pas!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output), markup);
    }
    else
    {
        gtk_label_set_text(GTK_LABEL(output), "");
        f = fopen(fich, "r");
        f1 = fopen(rech, "w");
        if ((f != NULL) && (f1 != NULL))
        {
            while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
            {
                if (strcmp(ID, u.id) == 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec);
                }
            }
        }
        fclose(f1);
        fclose(f);
        gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(aff_gpl);
        treeviewgpl = lookup_widget(aff_gpl, "treeviewpl_gpl");
        affPl(treeviewgpl, rech);
        remove("rech.txt");
    }
}
void on_buttonretaff_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *aff_gpl;

    aff_gpl = lookup_widget(button, "aff_gpl");
    gtk_widget_destroy(aff_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}
void on_treeviewpl_gpl_row_activated(GtkTreeView *treeviewpl,
                                     GtkTreePath *path,
                                     GtkTreeViewColumn *column,
                                     gpointer user_data)
{
    GtkTreeIter iter;
    gchar *id, *var, *type, *recolte, *dtpl, *dtrec, *stock;
    GtkWidget *aff_gpl, *modifsup_gpl;
    GtkWidget *ID;
    PLANTE p;
    PLANTE u;
    int vari;
    FILE *f1;
    char fich[20];
    aff_gpl = lookup_widget(treeviewpl, "aff_gpl");
    GtkTreeModel *model = gtk_tree_view_get_model(treeviewpl);
    if (gtk_tree_model_get_iter(model, &iter, path))
    {
        gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id, 1, &var, 2, &type, 3, &recolte, 4, &stock, 5, &dtpl, 6, &dtrec, -1);
        strcpy(p.id, id);
        strcpy(p.cat, var);
        strcpy(p.type, type);
        strcpy(p.recolte, recolte);
        strcpy(p.dtpl, dtpl);
        strcpy(p.dtrec, dtrec);
        f1 = fopen("plantes.txt", "r");
        if (f1 != NULL)
        {
            while (fscanf(f1, "%s %s %s %s %s %s %s \n", u.id, u.cat, u.type, u.recolte, u.stock, u.dtpl, u.dtrec) != EOF)
            {
                if (strcmp(u.id, p.id) == 0)
                {
                    if ((strcmp(u.cat, "Fruits")) == 0)
                    {
                        vari = 1;
                    }
                    else if ((strcmp(u.cat, "Legumes")) == 0)
                    {
                        vari = 2;
                    }
                }
            }
        }
        fclose(f1);
        modifsup_gpl = create_modifsup_gpl();
        gtk_widget_hide(aff_gpl);
        gtk_window_set_position(GTK_WINDOW(modifsup_gpl), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(modifsup_gpl);

        ID = lookup_widget(modifsup_gpl, "cbidmod_gpl");
        gtk_combo_box_insert_text(GTK_COMBO_BOX(ID), 0, p.id);
        gtk_combo_box_set_active(GTK_COMBO_BOX(ID), 0);
    }
}

void on_lraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varaj = 2;
    }
}

void on_fraj_gpl_toggled(GtkToggleButton *togglebutton,
                         gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varaj = 1;
    }
}

void on_buttonrejat_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *ajout_gpl;

    ajout_gpl = lookup_widget(button, "ajout_gpl");
    gtk_widget_destroy(ajout_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}

void on_buttonvalaj_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE p;
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_ajout;
    GtkWidget *ajout_gpl, *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    output_ajout = lookup_widget(button, "outputaj_gpl");
    gtk_label_set_text(GTK_LABEL(output_ajout), "");
    id = lookup_widget(button, "idaj_gpl");
    fruits = lookup_widget(button, "fraj_gpl");
    legumes = lookup_widget(button, "lraj_gpl");
    typefr = lookup_widget(button, "cbtypefaj_gpl");
    typeleg = lookup_widget(button, "cbtypelraj_gpl");
    recolte = lookup_widget(button, "recaj_gpl");
    qstock = lookup_widget(button, "stockaj_gpl");

    jpl = lookup_widget(button, "spinjplaj_gpl");
    mpl = lookup_widget(button, "spinmplaj_gpl");
    apl = lookup_widget(button, "spinaplaj_gpl");

    jrec = lookup_widget(button, "spinjraj_gpl");
    mrec = lookup_widget(button, "spinmraj_gpl");
    arec = lookup_widget(button, "spinaraj_gpl");

    if (verifPl(gtk_entry_get_text(GTK_ENTRY(id)), fich))
    {
        sprintf(msg, "La plante existe déjà!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(recolte))))
    {
        sprintf(msg, "La recolte doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(qstock))))
    {
        sprintf(msg, "La qualtite en stock doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_ajout), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(p.id, gtk_entry_get_text(GTK_ENTRY(id)));
        strcpy(p.recolte, gtk_entry_get_text(GTK_ENTRY(recolte)));
        strcpy(p.stock, gtk_entry_get_text(GTK_ENTRY(qstock)));
        suppEspaces(p.id);
        suppEspaces(p.recolte);
        suppEspaces(p.stock);
        p.datePl.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jpl));
        p.datePl.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mpl));
        p.datePl.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(apl));

        p.dateRec.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrec));
        p.dateRec.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mrec));
        p.dateRec.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arec));

        //strcpy(p.cat, "Fruits");
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(fruits)))
        {
            strcpy(p.cat, "Fruits");
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typefr)));
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(legumes)))
        {
            strcpy(p.cat, "Legumes");
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typeleg)));
        }
        ajoutPl(p, fich);
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Ajout");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Plante ajoutée avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_frmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varmod = 1;
    }
}

void on_lrmod_gpl_toggled(GtkToggleButton *togglebutton,
                          gpointer user_data)
{
    if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
    {
        varmod = 1;
    }
}

void on_buttonokmod_gpl_clicked(GtkButton *button,
                                gpointer user_data)
{
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_modif;
    PLANTE m;
    char fich[20];
    strcpy(fich, "plantes.txt");

    output_modif = lookup_widget(button, "outputmod_gpl");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    id = lookup_widget(button, "cbidmod_gpl");
    fruits = lookup_widget(button, "frmod_gpl");
    legumes = lookup_widget(button, "lrmod_gpl");
    typefr = lookup_widget(button, "cbtypefmod_gpl");
    typeleg = lookup_widget(button, "cbtypelmod_gpl");
    recolte = lookup_widget(button, "recmod_gpl");
    qstock = lookup_widget(button, "stockmod_gpl");

    jpl = lookup_widget(button, "spinjplmod_gpl");
    mpl = lookup_widget(button, "spinmplmod_gpl");
    apl = lookup_widget(button, "spinaplmod_gpl");

    jrec = lookup_widget(button, "spinjrmod_gpl");
    mrec = lookup_widget(button, "spinmrmod_gpl");
    arec = lookup_widget(button, "spinarmod_gpl");
    m = rechPl(gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)), fich);
    if ((strcmp(m.cat, "Fruits") == 0))
    {
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(fruits), 1);
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(legumes), 0);
        if (strcmp(m.type, "Clementines") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 0);
        }
        else if (strcmp(m.type, "Grenades") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 1);
        }
        else if (strcmp(m.type, "Poires") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typefr), 2);
        }
    }
    else if ((strcmp(m.cat, "Legumes") == 0))
    {
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(fruits), 0);
        gtk_toggle_button_set_active(GTK_RADIO_BUTTON(legumes), 1);
        if (strcmp(m.type, "Carottes") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 0);
        }
        else if (strcmp(m.type, "Fenouils") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 1);
        }
        else if (strcmp(m.type, "Betteraves") == 0)
        {
            gtk_combo_box_set_active(GTK_COMBO_BOX(typeleg), 2);
        }
    }
    gtk_entry_set_text(GTK_ENTRY(recolte), m.recolte);
    gtk_entry_set_text(GTK_ENTRY(qstock), m.stock);
    sscanf(m.dtpl, "%d/%d/%d", &m.datePl.jour, &m.datePl.mois, &m.datePl.annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jpl), m.datePl.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mpl), m.datePl.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(apl), m.datePl.annee);
    sscanf(m.dtrec, "%d/%d/%d", &m.dateRec.jour, &m.dateRec.mois, &m.dateRec.annee);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(jrec), m.dateRec.jour);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(mrec), m.dateRec.mois);
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(arec), m.dateRec.annee);
}

void on_buttonvalmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *id, *fruits, *legumes, *typefr, *typeleg, *recolte, *qstock, *jpl, *mpl, *apl, *jrec, *mrec, *arec;
    GtkWidget *output_modif;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";
    PLANTE m;
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE p;

    output_modif = lookup_widget(button, "outputmod_gpl");
    gtk_label_set_text(GTK_LABEL(output_modif), "");
    id = lookup_widget(button, "cbidmod_gpl");
    fruits = lookup_widget(button, "frmod_gpl");
    legumes = lookup_widget(button, "lrmod_gpl");
    typefr = lookup_widget(button, "cbtypefmod_gpl");
    typeleg = lookup_widget(button, "cbtypelmod_gpl");
    recolte = lookup_widget(button, "recmod_gpl");
    qstock = lookup_widget(button, "stockmod_gpl");

    jpl = lookup_widget(button, "spinjplmod_gpl");
    mpl = lookup_widget(button, "spinmplmod_gpl");
    apl = lookup_widget(button, "spinaplmod_gpl");

    jrec = lookup_widget(button, "spinjrmod_gpl");
    mrec = lookup_widget(button, "spinmrmod_gpl");
    arec = lookup_widget(button, "spinarmod_gpl");
    if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(recolte))))
    {
        sprintf(msg, "La recolte doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else if (!verifNumPl(gtk_entry_get_text(GTK_ENTRY(qstock))))
    {
        sprintf(msg, "La qualtite en stock doit avoir que des chiffres!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(output_modif), markup);
    }
    else
    {
        format = "<span foreground=\"green\"><b>\%s</b></span>";
        strcpy(p.id, gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));
        strcpy(p.recolte, gtk_entry_get_text(GTK_ENTRY(recolte)));
        strcpy(p.stock, gtk_entry_get_text(GTK_ENTRY(qstock)));
        suppEspaces(p.recolte);
        suppEspaces(p.stock);

        p.datePl.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jpl));
        p.datePl.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mpl));
        p.datePl.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(apl));

        p.dateRec.jour = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jrec));
        p.dateRec.mois = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mrec));
        p.dateRec.annee = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(arec));
        strcpy(p.cat, "Fruits");
        if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(fruits)))
        {
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typefr)));
            strcpy(p.cat, "Fruits");
        }
        else if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(legumes)))
        {
            strcpy(p.type, gtk_combo_box_get_active_text(GTK_COMBO_BOX(typeleg)));
            strcpy(p.cat, "Legumes");
        }
        modifPl(p, p.id, fich);
        succ_wadm = create_succ_wadm();
        gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Modification");
        gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
        gtk_widget_show(succ_wadm);
        msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
        sprintf(msg, "Plante modifiée avec succes!");
        markup = g_markup_printf_escaped(format, msg);
        gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
    }
}

void on_buttonvalsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    char fich[20];
    strcpy(fich, "plantes.txt");
    PLANTE s;
    GtkWidget *id;
    GtkWidget *succ_wadm, *msg_succ;
    char msg[50], *markup;
    const char *format = "<span foreground=\"red\"><b>\%s</b></span>";

    id = lookup_widget(button, "cbidmod_gpl");
    suppPl(gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)), fich);

    succ_wadm = create_succ_wadm();
    gtk_window_set_title(GTK_WINDOW(succ_wadm), "Succes Suppression");
    gtk_window_set_position(GTK_WINDOW(succ_wadm), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(succ_wadm);
    msg_succ = lookup_widget(succ_wadm, "hwlabelsucc_wadm");
    sprintf(msg, "Plante supprimée!");
    markup = g_markup_printf_escaped(format, msg);
    gtk_label_set_markup(GTK_LABEL(msg_succ), markup);
}

void on_buttonretmod_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *modifsup_gpl;

    modifsup_gpl = lookup_widget(button, "modifsup_gpl");
    gtk_widget_destroy(modifsup_gpl);

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gestionPlantation = create_gestionPlantation();
    gtk_window_set_position(GTK_WINDOW(gestionPlantation), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(gestionPlantation);
}
void on_buttonaj_gpl_clicked(GtkButton *button,
                             gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *ajout_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    ajout_gpl = create_ajout_gpl();
    gtk_window_set_position(GTK_WINDOW(ajout_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(ajout_gpl);
}

void on_buttonmodsup_gpl_clicked(GtkButton *button,
                                 gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *modifsup_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    modifsup_gpl = create_modifsup_gpl();
    gtk_window_set_position(GTK_WINDOW(modifsup_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(modifsup_gpl);
}

void on_buttonaff_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
    GtkWidget *gestionPlantation;
    GtkWidget *aff_gpl;

    gestionPlantation = lookup_widget(button, "gestionPlantation");
    gtk_widget_destroy(gestionPlantation);

    aff_gpl = lookup_widget(button, "aff_gpl");
    aff_gpl = create_aff_gpl();
    gtk_window_set_position(GTK_WINDOW(aff_gpl), GTK_WIN_POS_CENTER_ALWAYS);
    gtk_widget_show(aff_gpl);
}

void on_buttoncal_gpl_clicked(GtkButton *button,
                              gpointer user_data)
{
}

void on_buttongequi_ee_clicked(GtkButton *button,
                               gpointer user_data)
{
}

void on_buttongtroup_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
}

void on_buttongclients_ee_clicked(GtkButton *button,
                                  gpointer user_data)
{
}

void on_buttongcapts_ee_clicked(GtkButton *button,
                                gpointer user_data)
{
}
