#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "gestionPl.h"
enum
{
    PID,
    PVAR,
    PTYPE,
    PREC,
    PDTPL,
    PDTREC,
    PSTOCK,
    COLUMNS_P
};
//Definition des fonctions
/*---------------------------/CONTROLE-SAISIE/---------------------------*/
int verifNumPl(char num[])
{
    int t = 0;
    int i = 0;
    for (i = 0; i < strlen(num); i++)
    {
        if (num[i] >= '0' && num[i] <= '9')
        {
            t = 1;
        }
        else
        {
            return 0;
            break;
        }
    }
    return t;
}

int verifPl(char id[], char fich[])
{
    PLANTE p;
    int test = 0;
    FILE *f1;
    f1 = fopen(fich, "r");
    if (f1 != NULL)
    {
        while (fscanf(f1, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock) != EOF)
        {
            if ((strcmp(id, p.id) == 0))
            {
                test = 1;
            }
        }
        fclose(f1);
    }
    return test;
}

/*---------------------------/C-R-U-D/---------------------------*/
/*---------------------------/TACHE1/---------------------------*/
//Ajout d'une Plante
void ajoutPl(PLANTE p, char fich[])
{
    FILE *f;
    sprintf(p.dtpl, "%d/%d/%d", p.datePl.jour, p.datePl.mois, p.datePl.annee);
    sprintf(p.dtrec, "%d/%d/%d", p.dateRec.jour, p.dateRec.mois, p.dateRec.annee);
    f = fopen(fich, "a+");
    if (f != NULL)
    {
        fprintf(f, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock);
        fclose(f);
    }
}

//Modification des informations
void modifPl(PLANTE m, char id[], char fich[])
{
    PLANTE u;
    FILE *f1 = NULL, *f = NULL;
    sprintf(m.dtpl, "%d/%d/%d", m.datePl.jour, m.datePl.mois, m.datePl.annee);
    sprintf(m.dtrec, "%d/%d/%d", m.dateRec.jour, m.dateRec.mois, m.dateRec.annee);
    sprintf(u.dtpl, "%d/%d/%d", u.datePl.jour, u.datePl.mois, u.datePl.annee);
    sprintf(u.dtrec, "%d/%d/%d", u.dateRec.jour, u.dateRec.mois, u.dateRec.annee);
    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if ((f != NULL) && (f1 != NULL))
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock) != EOF)
        {
            if (strcmp(id, u.id) != 0)
            {
                fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock);
            }
            else
            {
                fprintf(f1, "%s %s %s %s %s %s %s \n", m.id, m.var, m.type, m.recolte, m.dtpl, m.dtrec, m.stock);
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Suppression d'une Plante
void suppPl(char id[], char fich[])
{
    PLANTE u;
    FILE *f1 = NULL, *f = NULL;

    f = fopen(fich, "r");
    f1 = fopen("tmp.txt", "w");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock) != EOF)
        {
            if (f1 != NULL)
            {
                if (strcmp(id, u.id) != 0)
                {
                    fprintf(f1, "%s %s %s %s %s %s %s \n", u.id, u.var, u.type, u.recolte, u.dtpl, u.dtrec, u.stock);
                }
            }
        }
    }
    fclose(f);
    fclose(f1);
    remove(fich);
    rename("tmp.txt", fich);
}

//Recherche des informations d'une Plante
PLANTE rechPl(char id[], char fich[])
{
    FILE *f = NULL;
    PLANTE p;
    //sscanf(u.dateNaiss, "%d/%d/%d", &u.date.jour, &u.date.mois, &u.date.annee);
    f = fopen(fich, "r");
    if (f != NULL)
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock) != EOF)
        {
            if (strcmp(id, p.id) == 0)
            {
                return p;
            }
        }
    }
    fclose(f);
}

//Affichage des plantes existantes
void affPl(GtkWidget *treeviewpl, char fich[])
{
    GtkCellRenderer *renderer;
    GtkTreeViewColumn *column;
    GtkTreeIter iter;
    GtkListStore *store;
    PLANTE p;
    gtk_list_store_clear(treeviewpl);
    FILE *f = NULL;
    store = gtk_tree_view_get_model(treeviewpl);
    if (store == NULL)
    {
        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" ID", renderer, "text", PID, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" VARIETE", renderer, "text", PVAR, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" TYPE", renderer, "text", PTYPE, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" RECOLTE (kg)", renderer, "text", PREC, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" DATE PLANTATION", renderer, "text", PDTPL, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" DATE RECOLTE", renderer, "text", PDTREC, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);

        renderer = gtk_cell_renderer_text_new();
        column = gtk_tree_view_column_new_with_attributes(" STOCK (kg)", renderer, "text", PSTOCK, NULL);
        gtk_tree_view_append_column(GTK_TREE_VIEW(treeviewpl), column);
    }
    store = gtk_list_store_new(COLUMNS_P, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

    f = fopen(fich, "r");
    if (f == NULL)
    {
        return;
    }
    else
    {
        while (fscanf(f, "%s %s %s %s %s %s %s \n", p.id, p.var, p.type, p.recolte, p.dtpl, p.dtrec, p.stock) != EOF)
        {
            gtk_list_store_append(store, &iter);
            gtk_list_store_set(store, &iter, PID, p.id, PVAR, p.var, PTYPE, p.type, PREC, p.recolte, PDTPL, p.dtpl, PDTREC, p.dtrec, PSTOCK, p.stock, -1);
        }
        gtk_tree_view_set_model(GTK_TREE_VIEW(treeviewpl), GTK_TREE_MODEL(store));
        g_object_unref(store);
    }
    fclose(f);
}