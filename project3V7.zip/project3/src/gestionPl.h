#ifndef GESTIONPL_H_
#define GESTIONPL_H_
#include <stdio.h>
#include <gtk/gtk.h>

typedef struct
{
    int jour, mois, annee;
} DATEP;

typedef struct
{
    char id[50];
    char var[50];
    char type[50];
    char recolte[50];
    char dtpl[30];
    char dtrec[30];
    DATEP datePl;
    DATEP dateRec;
    char stock[50];
} PLANTE;

//Prototypes des fonctions
///1ere tache
////controle de saisie
int verifNumPl(char num[]);
int verifPl(char id[], char fich[]);
////CRUD
void ajoutPl(PLANTE p, char fich[]);
void modifPl(PLANTE m, char id[], char fich[]);
void suppPl(char id[], char fich[]);
PLANTE rechPl(char id[], char fich[]);
void affPl(GtkWidget *treeviewpl, char fich[]);

/*2eme tache
OUVRIER dateAuj(OUVRIER o);
void marquerAbs(OUVRIER o, char fich[]);
void modifAbs(OUVRIER m, char cin[], char fich[]);
void suppAbs(char cin[], char dt[], char fich[]);
void tauxAbs(char fich1[], char fich2[]);
OUVRIER calcAbs(char cinn[], char dtd[], char dtf[], char fich[]);
void affAbs(GtkWidget *treeviewaffabs, char fich[]);*/

#endif